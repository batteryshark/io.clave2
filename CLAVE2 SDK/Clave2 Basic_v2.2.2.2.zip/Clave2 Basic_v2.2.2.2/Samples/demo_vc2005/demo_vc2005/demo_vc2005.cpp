/**************************************************************************
* filename: main.cpp
*
* briefs:  show how to using static lib in Microsoft Visual Studio 2005
**************************************************************************/
#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "Sense_LC.h"
//---------------------------------------------------------------------------

char * error[] = {
	"LC_SUCCESS",
	"LC_OPEN_DEVICE_FAILED",
	"LC_FIND_DEVICE_FAILED",
	"LC_INVALID_PARAMETER",
	"LC_INVALID_BLOCK_NUMBER",
	"LC_HARDWARE_COMMUNICATE_ERROR",
	"LC_INVALID_PASSWORD",
	"LC_ACCESS_DENIED",
	"LC_ALREADY_OPENED",
	"LC_ALLOCATE_MEMORY_FAILED",
	"LC_INVALID_UPDATE_PACKAGE",
	"LC_OTHER_ERROR"
};

void printhex(unsigned char* data, unsigned int len) {
	int i = 0;
	for (i = 0; i < len; i++) {
		printf("%02X", data[i]);
	}
	printf("\n");

}

int main(int argc, char* argv[])
{
    lc_handle_t handle;
    int res, i;

    // getting get software info
    LC_software_info softInfo;
    res = LC_get_software_info(&softInfo);
    if(res) {
        printf("get_software_info failed\n");
		printf("ERROR CODE: %s\n",error[res]);
        getchar();
        return -1;
    }
    printf("\tsoftwre version: %d\n", softInfo.version);

    // opening LC device
    res = LC_open(0, 0, &handle);
    if(res) {
        printf("open failed\n");
		printf("ERROR CODE: %s\n",error[res]);
        getchar();
        return -1;
    }
    printf("\nopen success!\n");

    // verify normal user password
    res = LC_passwd(handle, 1, (unsigned char *) "a81c046a");  //"12345678" is user password
    if(res) {
        LC_close(handle);
        printf("verify password failed\n");
		printf("ERROR CODE: %s\n",error[res]);
        getchar();
        return -1;
    }
    printf("\nverify password success!\n");

    // encrypt data

    unsigned char In[] = { 0x21, 0xDD, 0xE5, 0x3B, 0xF9, 0xE9, 0xDD, 0x53, 0xA6, 0x25, 0x17, 0xEB, 0x11, 0x42, 0x93, 0x1C };
    unsigned char Out[] = {0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30, 0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a};
    unsigned char tmp[16];
    res = LC_decrypt(handle, In,  tmp);
    if(res){
		LC_close(handle);
		printf("encrypt failed\n");
		printf("ERROR CODE: %s\n",error[res]);
		getchar();
		return -1;
	}
    printf("\nencrypt OK!\n");
	printf("Key: ");
	printhex(tmp, 16);
	printf("\n");
	LC_close(handle);
    
}
//---------------------------------------------------------------------------
