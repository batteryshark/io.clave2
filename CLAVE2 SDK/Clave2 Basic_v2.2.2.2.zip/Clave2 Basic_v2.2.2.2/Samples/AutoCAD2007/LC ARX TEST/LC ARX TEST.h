#include <aced.h>
#include <rxregsvc.h>
#include <dbapserv.h>           // Host application services
#include <aced.h>               // aced stuff
#include <adslib.h>             // RXADS definitions
#include <acdocman.h>           // MDI document manager