1. Install jdk and set enviornmental varaible
2. Execute in the command line of this directory:
javac lc_java.java
3. Copy lc_java.dll (java dll) from API supporting package of installation directory to current directory
4. Execute
java lc_java
